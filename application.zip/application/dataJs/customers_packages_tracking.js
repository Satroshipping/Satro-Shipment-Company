$(document).ready(function () {

    $('#t_date').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true
    });
});