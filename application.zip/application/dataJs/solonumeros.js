"use strict";


function cdp_soloNumeros(e){
    var key = e.charCode;
    return key >= 44 && key <= 57;
}