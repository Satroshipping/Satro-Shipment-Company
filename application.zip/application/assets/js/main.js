(function ($) {
    "use strict";
    
    jQuery(document).ready(function($){
        

        $('#server-time').jsclock();

 
    });

}(jQuery));	







